#ifndef __QBITMAP_H
#define __QBITMAP_H

class QBitmap
{
 public:
  QBitmap(int w, int h, const unsigned char * bits, bool isXbitmap = FALSE) { }
  QBitmap() { }
};

#endif
