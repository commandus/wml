#ifndef __QAPPLICATION_H
#define __QAPPLICATION_H

class QApplication
{

};


#endif
