#ifndef __QAPP_H
#define __QAPP_H

class QApp
{
 public:
};

#endif
