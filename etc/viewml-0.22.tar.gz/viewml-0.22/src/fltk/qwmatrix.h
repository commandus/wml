#ifndef __QWMATRIX_H
#define __QWMATRIX_H

class QWMatrix
{
 public:
  QWMatrix & scale(double dx, double dy) { return *this; }  
};


#endif
