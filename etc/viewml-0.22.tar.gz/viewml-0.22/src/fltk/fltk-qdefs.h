#ifndef __FLTK_QDEFS_H
#define __FLTK_QDEFS_H

#define TRUE (1)
#define FALSE (0)
#define slots 
#define signals public

#define CHECK_PTR(p)

typedef unsigned char uchar;

enum GUIStyle {
    MacStyle, // OBSOLETE
    WindowsStyle,
    Win3Style, // OBSOLETE
    PMStyle, // OBSOLETE
    MotifStyle
};


#endif
