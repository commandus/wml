#ifndef _EPS_H
#define _EPS_H

void kimgio_epsf_read (QImageIO *image);
void kimgio_epsf_write (QImageIO *image);

#endif

