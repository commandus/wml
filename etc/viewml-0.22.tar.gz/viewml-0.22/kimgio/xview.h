#ifndef XVIEW_H
#define XVIEW_H

#include <qimage.h>
#include <qpixmap.h>

void kimgio_xv_read( QImageIO * );
void kimgio_xv_write( QImageIO * );

#endif
